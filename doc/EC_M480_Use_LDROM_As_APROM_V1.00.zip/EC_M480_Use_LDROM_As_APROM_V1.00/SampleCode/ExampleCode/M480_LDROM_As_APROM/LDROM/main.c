/*************************************************************************//**
 * @file     main.c
 * @version  V1.00
 * @brief    This program shows PH.0(Red LED) constantly toggle run on LDROM.
 *
 * @copyright (C) 2019 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/
#include <stdio.h>
#include "NuMicro.h"

#define PLL_CLOCK           192000000

typedef uint32_t (*pointfunc)();

pointfunc    func1, func2;

// Fast toggle PH.0(Red LED)
void Fastflash(uint32_t i)
{
    while (i > 0)
    {
        PH0 ^= 1;
        CLK_SysTickDelay(100000);
        i--;
    }
}

// Slow toggle PH.0(Red LED)
void Slowflash(uint32_t i)
{
    while (i > 0)
    {
        PH0 ^= 1;
        CLK_SysTickDelay(1000000);
        i--;
    }
}

void SYS_Init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Set XT1_OUT(PF.2) and XT1_IN(PF.3) to input mode */
    PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);

    /* Enable External XTAL (4~24 MHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_HXTEN_Msk);

    /* Waiting for 12MHz clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Set core clock as PLL_CLOCK from PLL */
    CLK_SetCoreClock(PLL_CLOCK);
    /* Set PCLK0/PCLK1 to HCLK/2 */
    CLK->PCLKDIV = (CLK_PCLKDIV_PCLK0DIV2 | CLK_PCLKDIV_PCLK1DIV2);

    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
    SystemCoreClockUpdate();

    /* Lock protected registers */
    SYS_LockReg();
}

int main()
{
    // Fast changes PH.0(Red LED) status
    func1 = (pointfunc)Fastflash;
    // Slow changes PH.0(Red LED) status
    func2 = (pointfunc)Slowflash;

    /* Got no where to go, just loop forever */
    while (1);

}

/*** (C) COPYRIGHT 2019 Nuvoton Technology Corp. ***/
